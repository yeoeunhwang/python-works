file = open('camp_fire_file')
count = int(file.readline())
original_campfire = []
for i in range(count):
    v = file.readline()
    t, x, y = v.split()
    wanted_c = [int(t), int(x), int(y)]
    OkFail = True
    for c in original_campfire:
        d = (wanted_c[1]-c[1]) ** 2 + (wanted_c[2]-c[2]) ** 2
        if d < 25:
            if wanted_c[0] < c[0] + 300:
                OkFail = False
                continue
    if OkFail:
        original_campfire.append(wanted_c)
        print('S_OK')
    else:
        print('E_FAILED')

