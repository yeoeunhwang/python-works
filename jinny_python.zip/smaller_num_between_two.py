def smaller_between_two(num):
    final_number = 0
    backword_num = 0
    count = 0
    number = num
    while number > 0:
        number = number // 10
        count += 1
    if count % 2 == 0:
        while num:
            num1 = num % 10
            num //= 10
            num2 = num % 10
            num //= 10
            backword_num *= 10
            if num1 < num2:
                backword_num += num1
            else:
                backword_num += num2
    for i in range(count//2):
        numb = backword_num % 10
        final_number *= 10
        final_number += numb
        backword_num = backword_num//10

    return final_number


print(smaller_between_two(123456))





