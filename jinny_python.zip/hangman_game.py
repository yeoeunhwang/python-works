def discover_star(word, life):
    guessed_letter = []
    star_text = '*' * len(word)
    list_star_text = list(star_text)
    while life != 0 and star_text != word:
        star_text = ''.join(list_star_text)
        result = False
        s = input('enter your guess' + '\n' + star_text + '\n')
        if s == '' and star_text == word:
            return True
        for i in range(len(word)):
            if s == word[i]:
                list_star_text[i] = s
                result = True
        if s in guessed_letter:
            result = False
        else:
            guessed_letter.append(s)
        if not result:
            life -= 1
        print('life = ' + str(life))
    if star_text != word:
        return False


def hangman():
    secret = 'hwang'
    life = 5
    if discover_star(secret, life):
        print('great')
    else:
        print('bad')


hangman()




