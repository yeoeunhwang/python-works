class Complex:
    def __init__(self, r, i):
        self.real = r
        self.imaginary = i

    def __add__(self, other):
        add_real = self.real + other.real
        add_imaginary = self.imaginary + other.imaginary
        return Complex(add_real, add_imaginary)

    def __sub__(self, other):
        sub_real = self.real - other.imaginary
        sub_imaginary = self.imaginary - other.imaginary
        return Complex(sub_real, sub_imaginary)

    def __mul__(self, other):
        mul_real = self.real * other.real - self.imaginary * other.imaginary
        mul_imaginary = self.real * other.imaginary + self.imaginary * other.real
        return Complex(mul_real, mul_imaginary)

    def __truediv__(self, other):
        div_real = (self.real*other.real + self.imaginary * other.imaginary) / (other.real ** 2 + other.imaginary ** 2)
        div_imaginary = (self.imaginary * other.real - self.real * other.imaginary) / (other.real ** 2 + other.imaginary ** 2)
        return Complex(div_real, div_imaginary)

    def __str__(self):
        op = '+'
        print_this = str(self.real) + op + str(self.imaginary) + 'i'
        if self.real == 0 and self.imaginary != 0:
            print_this = str(self.imaginary) + 'i'
        elif self.imaginary == 0 and self.real != 0:
            print_this = str(self.real)
        elif self.real == 0 and self.imaginary == 0:
            print_this = '0'
        elif self.imaginary < 0:
            op = '-'
            self.imaginary += self.imaginary*2
        print(print_this, end = '')
        return ''


m1 = Complex(1,1)
m2 = Complex(2,1)

c = Complex(1,1) / (Complex(0, -1.0))
print('c', c.real, c.imaginary)
add = m1 + m2
sub = m1 - m2
mul = m1 * m2
div = m1 / m2
print(add)
print(sub)
print(mul)
print(div)
