def time_round(times):
    rounded = []
    return_list = []
    for i in times:
        y, mo, d, h, mi, s = i.split(':')
        y = int(y)
        mo = int(mo)
        d = int(d)
        h = int(h)
        mi = int(mi)
        integral, fraction = s.split('.')
        integral = int(integral)
        f = int(fraction[0])
        if f >= 5:
            integral += 1
        if integral >= 60:
            integral -= 60
            mi += 1
        if mi >= 60:
            mi -= 60
            h += 1
        if h >= 24:
            h -= 24
            d += 1
        original = mo
        if mo in (1,3,5,7,8,10,12):
            if d >= 31:
                mo += 1
                d -= 31
        if original in (2, 4, 6, 9, 11):
            print(d)
            if d >= 30:
                mo += 1
                d -= 30
        if mo >= 12:
            mo -= 12
            y += 1
        rounded.append(str(y)+':'+ str(mo)+ ':'+str(d)+':'+str(h)+':'+str(mi)+':'+str(integral))
    return rounded


print(time_round(['2018:12:30:24:13:59.762', '2017:9:29:24:17:9.823']))
