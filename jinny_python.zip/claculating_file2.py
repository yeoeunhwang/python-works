a = open('calculate_this2')

times = a.readline()
times = int(times)

for i in range(times):
    s = a.readline()
    n1, op, n2 = s.split()
    n1 = float(n1)
    n2 = float(n2)
    if op == '+':
        num = n1 + n2
        print(num)
    elif op == '-':
        num = n1 - n2
        print(num)
    elif op == '*':
        num = n1 * n2
        print(num)
    elif op == '/':
        num = n1 / n2
        print(num)
