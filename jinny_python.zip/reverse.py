def reverse_str(string):
    reversed_string = ''
    for a in string:
        reversed_string = a + reversed_string
    return reversed_string
32
s = 'abcd'
rs = reverse_str(s)
print('reverse of',s,'is',rs)


def reverse_list(list):
    reversed_list = []
    for a in list:
        reversed_list.insert(0, a)
    return reversed_list
    # for i in range(1, len(list)+1):
    #     reversed_list.append(list[len(list)-i])
    # return  reversed_list
l = [1,2,3,4]
rl = reverse_list(l)
print('reverse of',l,'is',rl)

def reverse_num(num):
    reverse_numb = 0
    while num > 0:
        reverse_numb *= 10
        reverse_numb += num%10
        num = num//10
    return reverse_numb

n = 1234
rn = reverse_num(n)
print('reverse of',n,'is',rn)

def is_palindrome_num(num):
    if num == reverse_num(num):
        return True
    else:
        return False
d = 12321
if is_palindrome_num(d):
    print(d,'is palindrome number')
else:
    print(d,'is not palindrome number')

