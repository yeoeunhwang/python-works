a = open('sample')
s = a.readline()
s1, s2, message = s.split()
i1 = int(s1)
i2 = int(s2)

print('int1 is', i1, type(i1))
print('int2 is', i2, type(i2))
print('message', message, type(message))
