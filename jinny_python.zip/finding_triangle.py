def find_triangle(total):
    for c in range(total//3, total):
        for a in range(1,c):
            b = total - a - c
            if b <= 0:
                break
            if b > a:
                continue
            if a**2 + b**2 == c**2:
                return a,b,c


t = find_triangle(1000)
print(t)
