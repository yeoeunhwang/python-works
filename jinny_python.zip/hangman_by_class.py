class Hangman:
    def __init__(self):
        self.secret = 'apple'
        self.life = 5
        self.guessed_letter = []
        self.star_text = '*' * len(self.secret)
        self.list_star_text = list(self.star_text)
        self.game_result = False

    def start_game(self):
        word = self.secret
        while self.life != 0:
            result = False
            self.star_text = ''.join(self.list_star_text)
            s = input('enter your guess' + '\n' + self.star_text + '\n')
            if s == '' and self.star_text == word:
                self.game_result = True
                return True
            for i in range(len(word)):
                if s == word[i]:
                    self.list_star_text[i] = s
                    result = True
            if s in self.guessed_letter and result:
                result = False
            else:
                self.guessed_letter.append(s)
            if not result:
                self.life -= 1
            print('life = ' + str(self.life))
        if self.star_text != word:
            return False

    def print_result(self):
        if self.game_result:
            print('Great')
        else:
            print('Bad')
        return''


hangman = Hangman()
hangman.start_game()
hangman.print_result()
