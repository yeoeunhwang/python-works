import random


def up_and_down():
    answer = random.randint(1,20)
    chance = 4
    guess = int(input('guess number 1~20. You have 5 chances \n'))
    for i in range(chance):
        if answer == guess:
            return True
        chance -= 1
        if guess > answer:
            guess = int(input('down\n'))
        elif guess < answer:
            guess = int(input('up\n'))
    return False


def guess_num():
    print("If your score = -2 you're out")
    score = 0
    wish_score = int(input('enter your wish score \n'))
    while wish_score > score:
        if score == -2:
            print('Mission Fail')
            return ''
        if up_and_down():
            score += 1
            print('score = ' + str(score))
            print('correct')
        else:
            score -= 1
            print('score = ' + str(score))
            print('incorrect')
    print('Mission success')
    return ''

guess_num()

