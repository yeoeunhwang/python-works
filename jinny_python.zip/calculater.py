def calculator():
    answer = input('if you want to start, tab anything\nif you want to finish, write "end"\n')
    while answer != 'end':
        answer = input('what do you want to claculate?\n')
        num1 = 0
        num2 = 0
        op = ''
        for c in answer:
            if '0' <= c <= '9':
                if op ==  '':
                    num1  *= 10
                    num1 += int(c)
                else:
                    num2 *= 10
                    num2 += int(c)
            else:
                op = c
        print(op)
        if op == '+':
            print(num1 + num2)
        elif op == '-':
            print(num1-num2)
        elif op == '*':
            print(num1*num2)
        elif op == '/':
            print(num1 // num2)
    return ''


calculator()

