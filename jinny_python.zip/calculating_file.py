a = open('calculate_this')

times = a.readline()
times = int(times)
# print(times)
op = a.readline().strip()
# print(calculate_with_this)
if op == '+':
    for i in range(times):
        n = a.readline()
        n1, n2 = n.split()
        n1 = float(n1)
        n2 = float(n2)
        num = n1 + n2
        print(num)
elif op == '-':
    for i in range(times):
        n = a.readline()
        n1, n2 = n.split()
        n1 = float(n1)
        n2 = float(n2)
        num = n1 - n2
        print(num)
elif op == '*':
    for i in range(times):
        n = a.readline()
        n1, n2 = n.split()
        n1 = float(n1)
        n2 = float(n2)
        num = n1 * n2
        print(num)
elif op == '/':
    for i in range(times):
        n = a.readline()
        n1, n2 = n.split()
        n1 = float(n1)
        n2 = float(n2)
        num = n1 / n2
        print(num)
