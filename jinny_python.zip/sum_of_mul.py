def sum_of_mul(n):
    sum = 0
    j = 1
    for i in range(1,n+1):
        mul = 1
        for _ in range(i):
            mul *= j
            j += 1
        sum += mul

    return sum


print(sum_of_mul(4))
