open = open('adding_file.txt')
nums = []
final_num = 0
for line in open:
    num = float(line)
    nums.append(num)
for i in nums:
    final_num += i

print(final_num)
