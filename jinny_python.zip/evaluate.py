def get_number(st, start):
    num = 0
    for i in range(start, len(st)):
        if '0' <= st[i] <= '9':
            int_c = ord(st[i]) - ord('0')
            num *= 10
            num += int_c
        else:
            pos = i
            return num, pos
    return num, len(st)


def skip_space(s, index):
    while s[index] == ' ':
        index += 1
        if index == len(s):
            return None
    return index


def evaluate(s):
    n1, index = get_number(s, 0)
    if index == len(s):
         return None
    index = skip_space(s, index)
    if index == None:
        return None
    op = s[index]
    index += 1
    if index == len(s):
        return None
    index = skip_space(s, index)
    n2, _ = get_number(s, index)
    if op == '+':
        return n1+n2
    if op == '-':
        return n1-n2
    if op == '*':
        return n1*n2
    if op == '/':
        return n1//n2


for s in ('23 +  5', '3 4*6', '32-6', '55 /5', '5 6', '56 ', '56  '):
    v = evaluate(s)
    print(s, '=', v)


