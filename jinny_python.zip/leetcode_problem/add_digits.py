def addDigits(num):
    while num >= 10:
        add = 0

        num = str(num)
        for c in num:
            add += int(c)
        num = add
    return num


print(addDigits(38))
