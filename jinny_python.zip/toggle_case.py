def toggle_case(s):
    toggled = ''
    for c in s:
        if 'A' <= c <= 'Z' :
            toggled += chr(ord(c) + ord('a') - ord('A'))
        elif 'a' <= c <= 'z':
            toggled += chr(ord(c) - ord('a') + ord('A'))
        else:
            toggled += c
    return toggled

s = 'ts3RsF'
v = toggle_case(s)
print('toggle case', s, '=>', v)

def capital_letter(s):
    capital = ''
    for c in s:
        if 'a' <= c <= 'z':
            capital += chr(ord(c) - ord('a') + ord('A'))
        else:
            capital += c
    return capital

s = 'ts3RsF'
v = capital_letter(s)
print('make capital letter', s, '=>', v)


def small_letter(s):
    small = ''
    for c in s:
        if 'A' <= c <= 'Z':
            small += chr(ord(c) + ord('a') - ord('A'))
        else:
            small += c
    return small

s = 'ts3RsF'
v = small_letter(s)
print('make small letter', s, '=>', v)
