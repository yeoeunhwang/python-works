import random


def calculate():
    op = random.randint(1,4)
    num1 = random.randint(1, 10)
    num2 = random.randint(11, 20)
    if op == 1:
        answer = num1 + num2
        guess = input(str(num1) + '+' + str(num2) + '\n')
    elif op == 2:
        answer = num2 - num1
        guess = input(str(num2) + '-' + str(num1) + '\n')
    elif op == 3:
        answer = num1 * num2
        guess = input(str(num1) + '*' + str(num2) + '\n')
    elif op == 4:
        answer = num2 // num1
        guess = input(str(num2) + '//' + str(num1) + '\n')
    if answer == int(guess):
        return True
    if answer != int(guess):
        return False


def calculating_game():
    print("If your score = -2 you're out")
    score = 0
    wish_score = int(input('enter your wish score \n'))
    while wish_score > score:
        if score == -2:
            print('Mission Fail')
            return ''
        if calculate():
            score += 1
            print('score = ' + str(score))
            print('correct')
        else:
            score -= 1
            print('score = '+ str(score))
            print('incorrect')
    print('Mission Complete')
    return ''


calculating_game()
