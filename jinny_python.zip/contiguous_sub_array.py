def contiguous_subarray(values):
    max_contiguous = 0
    current_contiguous = 0
    for i in values:
        # print(list[i])
        if i == 1:
            current_contiguous += 1
        else:
            if current_contiguous > max_contiguous:
                max_contiguous = current_contiguous
                # print(max_contiguous)
            current_contiguous = 0
    return max_contiguous


print(contiguous_subarray([1,1,1,0,0,1,1,1,1,1,0,0,0,0,0,1]))
