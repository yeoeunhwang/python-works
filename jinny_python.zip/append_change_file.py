a = open('a.txt','w')

a.write("hello\nI'm a\n")
a.close()

a_file = open('a.txt')
for line in a_file:
    print(line,end='')



