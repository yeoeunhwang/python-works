def no_0(num):
    while num != 0:
        if num % 10 == 0:
            return False
        num //= 10
    return True


def how_many_not_include_0(num):
    count = 0
    for i in range(1, num+1):
        if no_0(i):
            count += 1
    return count


# print(how_many_no_0(20))


def count_0(num):
    count = 0
    while num != 0:
        if num % 10 == 0:
            count += 1
        num //= 10
    return count


def how_many_0(num):
    count = 0
    for i in range(1, num+1):
        count += count_0(i)
    return count


print(how_many_0(100))




