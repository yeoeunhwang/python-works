def skip_duplicate(list):
    skip_duplicated = ''
    common_len = len(list[0])
    for i in range(len(list)-1):
        for j in range(common_len):
            if list[i][j] != list[i+1][j]:
                common_len = j
                break
    print(" ".join(list[0]))
    for i in range(1,len(list)):
        for j in range(len(list[0])):
            if j >= common_len:
                skip_duplicated += list[i][j]
            else:
                skip_duplicated += ' '*len(list[i][j])
            skip_duplicated += ' '
        skip_duplicated += '\n'
    return skip_duplicated

print(skip_duplicate([['adf', 't', 'y'],['adf', 't', 'h'],['adf', 'y', 't']]))

























































# def skip_duplicate(list):
#     skip_duplicated = ''
#     stop_point = len(list[0])
#     for i in range(len(list)-1):
#         for j in range(stop_point):
#             if list[i][j] != list[i+1][j]:
#                 stop_point = j
#                 break
#     for i in range(len(list)):
#         for j in range(len(list[0])):
#             if i == 0:
#                 skip_duplicated += list[i][j]
#             elif j >= stop_point:
#                 skip_duplicated += list[i][j]
#             else:
#                 skip_duplicated += ' '*len(list[i][j])
#             skip_duplicated += ' '
#         skip_duplicated += '\n'
#     return skip_duplicated
#
#
# print(skip_duplicate([['ac', 'cbf', 'b', 'g'], ['ac', 'c', 'y', 'g'], ['ac', 'c', 'y', 'j']]))

