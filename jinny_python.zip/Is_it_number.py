def is_number(n):
    for c in s:
        if '0' <= c <= '9':
            return True
    return False


s = '1238'
if is_number(s):
    print(s,'is number')
else:
    print(s, "isn't number")


['AB','dr','er'],['AB', 'dr', 'xo']
