def most_frequent_letter(st):
    frequent = {}
    best_letter = ''
    for i in st:
        if i in frequent:
            frequent[i] += 1
        else:
            frequent[i] = 1
        if best_letter == '':
            best_letter = i
        if frequent[best_letter] < frequent[i]:
            best_letter = i
    best_count = frequent[best_letter]
    return best_letter, best_count


print(most_frequent_letter('1233'))
print(most_frequent_letter('qpprqp'))
print(most_frequent_letter('q'))
